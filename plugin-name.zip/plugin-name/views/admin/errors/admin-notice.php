<div class="error">
	
	<p><?php echo $admin_notice; ?></p>
	
</div>