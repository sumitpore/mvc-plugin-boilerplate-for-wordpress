<p>
	<?php echo $text_example; ?>
</p>